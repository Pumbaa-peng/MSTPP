import torch
import torch.nn as nn
import math
from scipy import integrate
import numpy as np
import torch.nn.functional as F


import MSTPP.Constants as Constants

class DotDict(dict):
    __getattr__ = dict.__getitem__
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

def get_non_pad_mask(seq):
    """ Get the non-padding positions. """

    assert seq.dim() == 2
    return seq.ne(Constants.PAD).type(torch.float).unsqueeze(-1)

def clamp_preserve_gradients(x, min, max):
    """Clamp the tensor while preserving gradients in the clamped region."""
    return x + (x.clamp(min, max) - x).detach()

class Hypernet(nn.Module):
    """
        Hypernetwork deals with decoder input and generates params for mu, sigma, w
        对应论文公式(3)的线性变换部分，至于softmax, exp， 不在该网络中处理

    Args:
        config: Model configuration.
        hidden_sizes: Sizes of the hidden layers. [] corresponds to a linear layer.
        param_sizes: Sizes of the output parameters. [n_components, n_components, n_components] 分别指定w,mu,s的维度/components
        activation: Activation function.
    """
    def __init__(self, config, hidden_sizes=[], param_sizes=[1, 1, 1], activation=nn.Tanh()):
        super().__init__()
        self.decoder_input_size = config.decoder_input_size
        self.activation = activation

        # print("hidden_sizes:", hidden_sizes)  # []
        # print("param_sizes:", param_sizes)  # [64, 64, 64]
        # Indices for unpacking parameters
        ends = torch.cumsum(torch.tensor(param_sizes), dim=0)
        starts = torch.cat((torch.zeros(1).type_as(ends), ends[:-1]))
        self.param_slices = [slice(s.item(), e.item()) for s, e in zip(starts, ends)]
        # self.param_slices.shape =  [slice(0, 64, None), slice(64, 128, None), slice(128, 192, None)]

        self.output_size = sum(param_sizes)  # 最后要输出的数据的维度
        layer_sizes = list(hidden_sizes) + [self.output_size]
        # print("Hypernet layer_sizes:", layer_sizes)  # [192]
        # Bias used in the first linear layer
        self.first_bias = nn.Parameter(torch.empty(layer_sizes[0]).uniform_(-0.1, 0.1))  # 偏置项b,原作者把这一项单独处理了。
        self.first_linear = nn.Linear(self.decoder_input_size, layer_sizes[0], bias=False)

        # Remaining linear layers
        self.linear_layers = nn.ModuleList()
        for idx, size in enumerate(layer_sizes[:-1]):
            self.linear_layers.append(nn.Linear(size, layer_sizes[idx + 1]))

    def reset_parameters(self):
        '''
        默认的初始化
        '''
        self.first_bias.data.fill_(0.0)
        self.first_linear.reset_parameters()
        nn.init.orthogonal_(self.first_linear.weight)
        for layer in self.linear_layers:
            layer.reset_parameters()
            nn.init.orthogonal_(layer.weight)

    def forward(self, decoder_input):
        """Generate model parameters from the embeddings.

        Args:
            input: decoder input, shape (batch, decoder_input_size)

        Returns:
            params: Tuple of model parameters.
        """
        # Generate the output based on the input
        hidden = self.first_bias
        hidden = hidden + self.first_linear(decoder_input)
        for layer in self.linear_layers:
            hidden = layer(self.activation(hidden))

        # # Partition the output
        # if len(self.param_slices) == 1:
        #     return hidden
        # else:
        return tuple([hidden[..., s] for s in self.param_slices])



class TemporalPositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout, max_len, lookup_index=None):
        super(TemporalPositionalEncoding, self).__init__()

        self.dropout = nn.Dropout(p=dropout)
        self.lookup_index = lookup_index
        self.max_len = max_len
        # computing the positional encodings once in log space
        pe = torch.zeros(max_len, d_model)
        for pos in range(max_len):
            for i in range(0, d_model, 2):
                pe[pos, i] = math.sin(pos / (10000 ** ((2 * i)/d_model)))
                pe[pos, i+1] = math.cos(pos / (10000 ** ((2 * (i + 1)) / d_model)))

        pe = pe.unsqueeze(1)  # (1, T_max, d_model)
        self.register_buffer('pe', pe)
        # register_buffer:
        # Adds a persistent buffer to the module.
        # This is typically used to register a buffer that should not to be considered a model parameter.

    def forward(self, x):
        '''
        :param x: (batch_size, N, T, F_in)
        :return: (batch_size, N, T, F_out)
        '''
        if self.lookup_index is not None:
            x = x + self.pe[:self.lookup_index,:, :]  # (batch_size, N, T, F_in) + (1,1,T,d_model)
        else:
            x = x + self.pe[:x.size(0), :, :]
        return self.dropout(x.detach())



class cross_attn(nn.Module):

    def __init__(self, emb_size, time_emb_size, hidden_size,dropout=0.1):
        super(cross_attn, self).__init__()
        self.emb_size = emb_size
        self.time_emb_size = time_emb_size
        self.hidden_size = hidden_size

        self.multihead_attn1 = nn.MultiheadAttention(self.hidden_size, num_heads=4)
        self.multihead_attn2 = nn.MultiheadAttention(self.hidden_size, num_heads=4)

        self.query_w = nn.Linear(self.time_emb_size, self.hidden_size)
        self.key_e = nn.Linear(self.emb_size, self.hidden_size)
        self.value_e = nn.Linear(self.emb_size, self.hidden_size)

        self.query_tau = nn.Linear(self.time_emb_size, self.hidden_size)
        self.key_w = nn.Linear(self.time_emb_size, self.hidden_size)
        self.value_w = nn.Linear(self.time_emb_size, self.hidden_size)

        self.fce = nn.Linear(self.hidden_size, self.emb_size)
        self.fcw = nn.Linear(self.hidden_size, self.time_emb_size)
        self.pe1 = TemporalPositionalEncoding(emb_size, dropout, max_len=130, lookup_index=None)
        self.pe2 = TemporalPositionalEncoding(time_emb_size, dropout, max_len=130, lookup_index=None)

    def forward(self, input, w_input, x_tau_emb):
        input = input.permute(1,0,2)
        w_input = w_input.permute(1,0,2)
        x_tau_emb = x_tau_emb.permute(1,0,2)

        input = self.pe1(input)
        w_input = self.pe2(w_input)
        x_tau_emb = self.pe2(x_tau_emb)
        query_w = self.query_w(w_input)
        key_e = self.key_e(input)
        value_e = self.value_e(input)

        query_tau = self.query_tau(x_tau_emb)


        e_output, score1 = self.multihead_attn1(query_w, key_e, value_e)
        w_output, score2 = self.multihead_attn2(query_tau, key_e, key_e)


        p_attn = score1 * score2


        value_e=value_e.permute(1,0,2)
        e_output = torch.matmul(p_attn, value_e)

        e_output = self.fce(e_output)
        w_output = self.fcw(w_output.permute(1,0,2))

        return e_output,w_output


class AVWGCN(nn.Module):
    def __init__(self, dim_in, dim_out, embed_dim,cheb_k=2):
        super(AVWGCN, self).__init__()
        self.cheb_k = cheb_k
        self.weights_pool = nn.Parameter(torch.FloatTensor(embed_dim, cheb_k, dim_in, dim_out))
        self.bias_pool = nn.Parameter(torch.FloatTensor(embed_dim, dim_out))
    def forward(self, x, node_embeddings):
        batch = node_embeddings.shape[0]
        node_num = node_embeddings.shape[1]
        supports = F.softmax(F.relu(torch.bmm(node_embeddings, node_embeddings.transpose(1, 2))), dim=-1)


        support_set = [torch.eye(node_num).unsqueeze(0).repeat(batch,1,1).to(supports.device), supports]
        for k in range(2, self.cheb_k):
            support_set.append(torch.matmul(2 * supports, support_set[-1]) - support_set[-2])
        supports = torch.stack(support_set, dim=0)
        weights = torch.einsum('bnd,dkio->bnkio', node_embeddings, self.weights_pool)  #N, cheb_k, dim_in, dim_out
        bias = torch.matmul(node_embeddings, self.bias_pool)
        x_g = torch.einsum("kbnm,bmc->bknc", supports, x)      #B, cheb_k, N, dim_in
        x_g = x_g.permute(0, 2, 1, 3)  # B, N, cheb_k, dim_in
        x_gconv = torch.einsum('bnki,bnkio->bno', x_g, weights) + bias     #b, N, dim_out
        return x_gconv



import numpy as np
class MSTPP_ModelConfig(DotDict):
    '''
    configuration of the DeepMove
    '''
    def __init__(self, loc_num=None, loc_emb_size=None, time_interval_minutes=None, tim_emb_size=None,  hidden_size=None, rnn_type=None, num_layers=1, dropout=.0,  n_components=4, shift_init=0.0, scale_init=0.0, min_clip=-5., max_clip=3., hypernet_hidden_sizes=[]):
        super().__init__()
        self.loc_num = loc_num  # 地点个数
        self.loc_emb_size = loc_emb_size
        self.tim_num = 7 * 24 * 60 // time_interval_minutes + 1 # 时间点个数
        self.tim_emb_size = tim_emb_size
        self.hidden_size = hidden_size
        self.rnn_type = rnn_type
        self.num_layers = num_layers
        self.dropout = dropout
        self.n_components = n_components
        self.min_clip = min_clip
        self.max_clip = max_clip
        self.shift_init = shift_init
        self.scale_init = scale_init
        self.hypernet_hidden_sizes = hypernet_hidden_sizes
        self.decoder_input_size =  hidden_size


class CustomLSTM(nn.Module):
    def __init__(self, input_sz, hidden_sz):
        super().__init__()
        self.input_sz = input_sz
        self.hidden_size = hidden_sz
        self.W = nn.Parameter(torch.Tensor(input_sz, hidden_sz * 4))
        self.U = nn.Parameter(torch.Tensor(hidden_sz, hidden_sz * 4))
        self.bias = nn.Parameter(torch.Tensor(hidden_sz * 4))
        self.init_weights()
        self.w_dg_x = nn.Linear(1, self.hidden_size)

    def init_weights(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)

    def forward(self, x,x_tau,init_states=None):
        """Assumes x is of shape (batch, sequence, feature)"""
        bs, seq_sz, _ = x.size()
        input_zeros = torch.zeros(bs, seq_sz,self.hidden_size).to(x.device)


        x_tau_emb = torch.exp(-1 * torch.nn.functional.relu(self.w_dg_x(x_tau.unsqueeze(-1))))
        #x_tau_emb = torch.exp(-torch.max(input_zeros, self.w_dg_x(x_tau.unsqueeze(-1))))
        hidden_seq = []
        if init_states is None:
            h_t, c_t = (torch.zeros(bs, self.hidden_size).to(x.device),
                        torch.zeros(bs, self.hidden_size).to(x.device))
        else:
            h_t, c_t = init_states

        HS = self.hidden_size
        for t in range(seq_sz):
            x_t = x[:, t, :]
            # batch the computations into a single matrix multiplication
            gates = x_t @ self.W + h_t @ self.U + self.bias
            i_t, f_t, g_t, o_t = (
                torch.sigmoid(gates[:, :HS]),  # input
                torch.sigmoid(gates[:, HS:HS * 2]),  # forget
                torch.tanh(gates[:, HS * 2:HS * 3]),
                torch.sigmoid(gates[:, HS * 3:]),  # output
            )
            c_t = f_t * c_t + i_t * g_t
            #c_t = c_t * x_tau_emb[:, t, :]
            h_t = o_t * torch.tanh(c_t)
            h_t = h_t * x_tau_emb[:, t, :]



            hidden_seq.append(h_t.unsqueeze(0))
        hidden_seq = torch.cat(hidden_seq, dim=0)
        # reshape from shape (sequence, batch, feature) to (batch, sequence, feature)
        hidden_seq = hidden_seq.transpose(0, 1).contiguous()
        return hidden_seq, (h_t, c_t)



class MLP(nn.Module):
    def __init__(self, input_size, hidden_size, output_size,
                 dropout, use_selu=False):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.nonlinear_f = F.selu if use_selu else F.leaky_relu
        self.dropout = nn.Dropout(dropout)
    def forward(self, x):
        h1 = self.dropout(self.nonlinear_f(self.fc1(x)))
        return self.fc2(h1)





class MSTPP(nn.Module):

    def __init__(self, config):
        super(MSTPP, self).__init__()
        self.n_components = config.n_components
        self.min_clip = config.min_clip
        self.max_clip = config.max_clip
        self.shift_init = config.shift_init
        self.scale_init = config.scale_init
        self.loc_num = config.loc_num
        self.loc_emb_size = config.loc_emb_size
        self.tim_num = config.tim_num
        self.tim_emb_size = config.tim_emb_size
        self.hidden_size = config.hidden_size
        self.rnn_type = config.rnn_type
        self.num_layers = config.num_layers
        self.dropout = config.dropout
        self.max_len =128
        self.t_node_embeding = torch.nn.Parameter(torch.FloatTensor(self.max_len, self.loc_emb_size))

        self.m_node_embeding = torch.nn.Parameter(torch.FloatTensor(self.max_len, self.loc_emb_size))

        self.emb_loc = nn.Embedding(self.loc_num, self.loc_emb_size)

        self.emb_tim = nn.Embedding(self.tim_num, self.tim_emb_size)

        self.periodic = nn.Linear(1, self.tim_emb_size - 1)
        self.linear = nn.Linear(1, 1)

        self.w_dg_x = nn.Linear(1, self.hidden_size)

        #self.emb_flow = nn.Linear(2,self.loc_emb_size)
        self.flow_emb_size = 32
        self.emb_flow = nn.Linear(2, self.flow_emb_size)


        input_size =  2* self.tim_emb_size+self.loc_emb_size+self.flow_emb_size

        self.customlstm = CustomLSTM(input_size,self.hidden_size)
        if(self.num_layers>1):
            self.rnn = nn.LSTM(input_size, self.hidden_size, num_layers=self.num_layers, batch_first=True,
                               dropout=self.dropout)

        self.FCc2m = MLP(self.max_len, self.hidden_size, self.loc_num, self.dropout)
        self.encoder_layer = nn.TransformerEncoderLayer(d_model=self.hidden_size, nhead=8)

        self.t_deocder = cross_attn(self.hidden_size, self.hidden_size, self.hidden_size, self.dropout)

        #self.m_decoder = nn.TransformerEncoder(self.encoder_layer, num_layers=1)

        #self.t_deocder = AVWGCN(self.hidden_size, self.hidden_size, self.hidden_size)
        self.m_deocder = AVWGCN(self.hidden_size, self.hidden_size, self.hidden_size)

        self.fc = MLP(input_size, self.hidden_size, self.hidden_size, self.dropout)
        self.FCt = MLP(self.max_len, self.hidden_size, 1, self.dropout)
        self.FCm = MLP(self.max_len, self.hidden_size, 1, self.dropout)






        '''
        if self.rnn_type == 'GRU':
            self.rnn = nn.GRU(input_size, self.hidden_size, num_layers=self.num_layers, batch_first=True,
                              dropout=self.dropout)
        elif self.rnn_type == 'LSTM':
            self.rnn = nn.LSTM(input_size, self.hidden_size, num_layers=self.num_layers, batch_first=True,
                               dropout=self.dropout)
        elif self.rnn_type == 'RNN':
            self.rnn = nn.RNN(input_size, self.hidden_size, num_layers=self.num_layers, batch_first=True,
                              dropout=self.dropout)
        '''
        self.hypernet = Hypernet(config,
                                 hidden_sizes=config.hypernet_hidden_sizes,
                                 param_sizes=[config.n_components, config.n_components, config.n_components])

        self.decoder_s = nn.Linear(config.hidden_size, config.loc_num)

    def normal_logpdf(self, x, mean, log_scale):
        '''
        log pdf of the normal distribution with mean and log_sigma
        '''
        z = (x - mean) * torch.exp(-log_scale)
        return -log_scale - 0.5 * z.pow(2.0) - 0.5 * np.log(2 * np.pi)
    def learn_time_embedding(self, tt):
        #tt = tt.to(self.device)
        tt = tt.unsqueeze(-1)
        out2 = torch.sin(self.periodic(tt))
        out1 = self.linear(tt)
        return torch.cat([out1, out2], -1)

    def mixnormal_logpdf(self, x, log_prior, means, log_scales):
        '''
        :param x: ground truth
        :param log_prior:  归一化后的权重系数，(batch,max_length/actual_length,n_components)=(64, 128, 64),
        :param means: (batch,max_length/actual_length,n_components)=(64, 128, 64)
        :param log_scales: (batch,max_length/actual_length,n_components)=(64, 128, 64), scales对应论文中的s
        :return:
        '''
        return torch.logsumexp(
            log_prior + self.normal_logpdf(x.unsqueeze(-1), means, log_scales),
            dim=-1
        )

    def get_params(self, decoder_input):
        """
        Generate model parameters based on the inputs
        Args:
            input: decoder input [batch, decoder_input_size]

        Returns:
            prior_logits: shape [batch, n_components]
            means: shape [batch, n_components]
            log_scales: shape [batch, n_components]
        """
        prior_logits, means, log_scales = self.hypernet(decoder_input)

        # Clamp values that go through exp for numerical stability
        prior_logits = clamp_preserve_gradients(prior_logits, self.min_clip, self.max_clip)
        log_scales = clamp_preserve_gradients(log_scales, self.min_clip, self.max_clip)

        # normalize prior_logits
        prior_logits = F.log_softmax(prior_logits, dim=-1)  # 这里进行了权重w的归一化,而且之后进行了log
        return prior_logits, means, log_scales

    def forward(self, X_time,X_timeidx,X_tau,X_location,flow_in,flow_out):

        X_time = X_time[:, :-1]
        X_timeidx = X_timeidx[:, :-1]
        X_tau = X_tau[:, :-1]
        Y_tau = X_tau[:, -1]
        X_location = X_location[:, :-1]
        Y_location = X_location[:, -1]

        flow_in = flow_in[:, :-1]
        flow_out = flow_out[:, :-1]



        flow = torch.cat((flow_in.unsqueeze(-1), flow_out.unsqueeze(-1)),2)

        flow_emb = self.emb_flow(flow)



        t = Y_tau  # (batch,)
        loc_emb = self.emb_loc(X_location.long())  # (batch, max_all_length)-> (batch, max_all_length, loc_emb_size)
        tim_index_emb = self.emb_tim(X_timeidx.long())  # (batch, max_all_length)-> (batch, max_all_length, tim_emb_size)
        tim_emb = self.learn_time_embedding(X_time)



        x_tau_emb = torch.exp(-1 * torch.nn.functional.relu(self.w_dg_x(X_tau.unsqueeze(-1))))

        #x_tau_emb =X_tau.unsqueeze(-1)




        x = torch.cat((tim_index_emb,x_tau_emb,loc_emb,flow_emb),
                      2)  # (batch, max_all_length, 1+loc_emb_size + tim_emb_size)


        Batch,max_len,_ = x.shape
        #x = self.fc(x)
        #output = self.encoder(x.permute(1,0,2)).permute(1,0,2)
        #output_t,_=self.t_deocder(x,x,x_tau_emb)
        #x,(_,_) = self.customlstm(x,X_tau)
        x,_ = self.rnn(x)
        #x,(_,_) = self.customlstm(x,X_tau)

        #output_m= self.m_decoder(x)
        output_t,_ = self.t_deocder(x,x,x_tau_emb)
        output_m = self.m_deocder(x, self.m_node_embeding.unsqueeze(0).repeat(x.size(0), 1, 1))

        '''

        hidden_seq, (h_t, c_t) = self.customlstm(x,X_tau)


        if(self.num_layers>1):
            x = hidden_seq
            output, (h_n, _) = self.rnn(x)
            Context_out = output
        else:
            Context_out = hidden_seq
        '''






        out_t = self.FCt(output_t.permute(0, 2, 1)).squeeze(-1)
        out_m = self.FCm(output_m.permute(0, 2, 1)).squeeze(-1)



        loss_score = 0.0
        s_loss_score = None
        top_k_pred = None
        t_loss_score = None
        time_expectation = None


        ###### type process
        s_loss = nn.CrossEntropyLoss()
        predict_y = self.decoder_s(out_t)  # (batch, hidden_size+user_embed_size)->(batch, num_classes)


        _, top_k_pred = torch.topk(predict_y, k=self.loc_num)

        s_loss_score = 10 * s_loss(predict_y, Y_location)
        loss_score = loss_score + s_loss_score




        x = torch.log(t)

        x = (x - self.shift_init) / self.scale_init    # 归一化
        prior_logits, means, log_scales = self.get_params(out_m)
        log_p = self.mixnormal_logpdf(x, prior_logits, means, log_scales)
        prior = prior_logits.exp()  # (batch, n_components=64)
        scales_squared = (log_scales * 2).exp()
        a = self.scale_init
        b = self.shift_init
        mean_time = (prior * torch.exp(a * means + b + 0.5 * a ** 2 * scales_squared)).sum(-1)
        #print('y_tau_hat:',mean_time,t)

        t_loss_score = -log_p.mean()
        loss_score = loss_score + t_loss_score
        time_expectation = mean_time
        return loss_score, s_loss_score, t_loss_score, top_k_pred, time_expectation







