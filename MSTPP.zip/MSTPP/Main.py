import argparse
import numpy as np
import pickle
import time
import torch
import torch.nn as nn
import torch.optim as optim

import MSTPP.Constants as Constants
import random
import Utils
from preprocess.Dataset import get_dataloader
from MSTPP.model import *
from tqdm import tqdm
import gc

GLOBAL_SEED = 2


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed(GLOBAL_SEED)




def prepare_dataloader(opt):
    """ Load data and prepare dataloader. """
    '''
    def load_data(name, dict_name):
        with open(name, 'rb') as f:
            data = pickle.load(f, encoding='latin-1')
            num_types = data['dim_process']
            data = data[dict_name]
            return data, int(num_types)
    print('[Info] Loading train data...')
    train_data, num_types = load_data(opt.data + 'train.pkl', 'train')
    print('[Info] Loading dev data...')
    dev_data, _ = load_data(opt.data + 'dev.pkl', 'dev')
    print('[Info] Loading test data...')
    test_data, _ = load_data(opt.data + 'test.pkl', 'test')
    '''
    import math
    def timestemp_to_time_idx(timestemp):
        time_str = time.localtime(timestemp)
        wday = time_str.tm_wday
        hour = time_str.tm_hour
        min = time_str.tm_min
        idx = wday * 144 + hour * 6 + math.ceil((min * 1.0) / 10.0)
        return idx

    def get_mean_std_X_tau(seq):
        seq_list = []
        Y_tau = []
        for item in seq:
            event_list = []
            Y_tau.append(item[-1][1])
            for event in item:
                dic = []
                # dic['time_since_start'] = event[0]
                dic.append(event[1])
                event_list.append(dic)

            seq_list.append(event_list)

        X_taus = torch.tensor((np.array(seq_list)))
        Y_tau = torch.tensor((np.array(Y_tau)))

        """Get mean and std of X_tau."""
        logy = Y_tau.log()

        return X_taus.mean(), X_taus.std(), logy.mean(), logy.std()

    def list_to_dic(seq, mean, std):
        seq_list = []
        for item in seq:
            event_list = []
            for event in item:
                dic = {}
                # dic['time_since_start'] = event[0]
                dic['time_since_start'] = event[0]
                dic['time_since_start_index'] = timestemp_to_time_idx(event[0])
                dic['time_since_last_event'] = event[1]
                dic['type_event'] = event[-1]
                dic['flow_in'] = event[-3]
                dic['flow_out'] = event[-2]
                dic['mean'] = mean
                dic['std'] = std
                event_list.append(dic)
            seq_list.append(event_list)

        return seq_list

    def load_accident_data(name):
        data = np.load(name, allow_pickle=True)
        X = data['X']
        Y = data['label']
        # print(type(X))
        # print(Y.shape)
        all_events_seq = np.concatenate([X, Y], axis=1)
        x_tau_mean, x_tau_std, trainY_tau_mean, trainY_tau_std = get_mean_std_X_tau(all_events_seq)
        # print(all_events_seq.shape)
        all_events_seq = all_events_seq[:5000, ...]

        split_line1 = int(len(all_events_seq) * 0.6)
        split_line2 = int(len(all_events_seq) * 0.8)

        train_seq = all_events_seq[:split_line1, ...]
        dev_seq = all_events_seq[split_line1:split_line2, ...]
        test_seq = all_events_seq[split_line2:, ...]
        print("train sample num:", len(train_seq))
        print("dev sample num:", len(dev_seq))
        print("test sample num:", len(test_seq))

        train_data = list_to_dic(train_seq, x_tau_mean, x_tau_std)
        dev_data = list_to_dic(dev_seq, x_tau_mean, x_tau_std)
        test_data = list_to_dic(test_seq, x_tau_mean, x_tau_std)

        num_types = 57  # there are 58 event types

        return train_data, dev_data, test_data, num_types, x_tau_mean, x_tau_std, trainY_tau_mean, trainY_tau_std

    train_data, dev_data, test_data, num_types, x_tau_mean, x_tau_std, trainY_tau_mean, trainY_tau_std = load_accident_data(
        opt.data)

    trainloader = get_dataloader(train_data, opt.batch_size, shuffle=True)
    testloader = get_dataloader(test_data, opt.batch_size, shuffle=False)
    return trainloader, testloader, num_types, x_tau_mean, x_tau_std, trainY_tau_mean, trainY_tau_std


def train_epoch(model, x_tau_mean, x_tau_std, training_data, optimizer, pred_loss_func, opt,pt_matrix):
    """ Epoch operation in training phase. """

    model.train()


    total_event_ll = 0
    all_ground_truth_location = []
    all_predicted_topK = []
    total_pred_time = []
    total_true_time = []
    total_num_pred = 0
    for batch in tqdm(training_data, mininterval=2,
                      desc='  - (Training)   ', leave=False):
        """ prepare data """
        event_time,event_time_index, time_gap, event_type, flow_in, flow_out = map(lambda x: x.to(opt.device), batch)


        ## normalization
        # time_gap = (time_gap - x_tau_mean) / x_tau_std
        total_true_time.extend(event_time[:, -1].cpu().detach().numpy())
        Batch_size, seq_len = event_type.size()
        total_num_pred += Batch_size * seq_len

        """ forward """
        optimizer.zero_grad()
        loss_score, s_loss_score, t_loss_score, top_k_pred, time_expectation = model(event_time,event_time_index, time_gap, event_type,
                                                                                     flow_in, flow_out)

        total_event_ll += -t_loss_score.item()
        time_expectation = time_expectation.detach().cpu().numpy()  # * x_tau_std.numpy() + x_tau_mean.numpy()
        total_pred_time.extend(time_expectation + event_time[:, -2].cpu().detach().numpy())

        all_ground_truth_location.append(event_type[:, -1].cpu().numpy())
        all_predicted_topK.append(top_k_pred.cpu().numpy())

        """ backward """
        loss = loss_score
        #loss.backward()
        s_loss_score.backward(retain_graph=True)
        t_loss_score.backward()

        """ update parameters """
        optimizer.step()

        """ note keeping """
    t_loss = total_event_ll / total_num_pred
    all_ground_truth_location = np.concatenate(all_ground_truth_location)
    all_predicted_topK = np.concatenate(all_predicted_topK)
    hit_ratio, mrr = Utils.evaluate_location(all_ground_truth_location, all_predicted_topK)

    rmse = np.sqrt(((np.array(total_pred_time) - np.array(total_true_time)) ** 2).mean())

    del all_ground_truth_location
    del all_predicted_topK
    del total_pred_time
    del total_true_time
    del total_num_pred
    del event_time
    del time_gap
    del event_type
    del flow_in
    del flow_out
    gc.collect()

    return t_loss, hit_ratio, rmse


def eval_epoch(model, x_tau_mean, x_tau_std, validation_data, pred_loss_func, opt,pt_matrix):
    """ Epoch operation in evaluation phase. """

    model.eval()

    total_event_ll = 0
    all_ground_truth_location = []
    all_predicted_topK = []
    total_pred_time = []
    total_true_time = []
    total_num_pred = 0
    with torch.no_grad():
        for batch in tqdm(validation_data, mininterval=2,
                          desc='  - (Validation) ', leave=False):
            """ prepare data """
            event_time,event_time_index, time_gap, event_type, flow_in, flow_out = map(lambda x: x.to(opt.device), batch)

            Batch_size, seq_len = event_type.size()


            """ forward """
            # time_gap = (time_gap - x_tau_mean) / x_tau_std
            total_true_time.append(event_time[:, -1].cpu().detach().numpy())
            total_num_pred += Batch_size * seq_len
            loss_score, s_loss_score, t_loss_score, top_k_pred, time_expectation = model(event_time,event_time_index, time_gap,
                                                                                         event_type, flow_in, flow_out)

            total_event_ll += -t_loss_score.item()
            time_expectation = time_expectation.detach().cpu().numpy()  # * x_tau_std.numpy() + x_tau_mean.numpy()
            total_pred_time.append(time_expectation + event_time[:, -2].cpu().detach().numpy())

            all_ground_truth_location.append(event_type[:, -1].cpu().numpy())
            all_predicted_topK.append(top_k_pred.cpu().numpy())
        t_loss = total_event_ll / total_num_pred
        all_ground_truth_location = np.concatenate(all_ground_truth_location)
        all_predicted_topK = np.concatenate(all_predicted_topK)
        hit_ratio, mrr = Utils.evaluate_location(all_ground_truth_location, all_predicted_topK)
        rmse = np.sqrt(((np.array(total_pred_time) - np.array(total_true_time)) ** 2).mean())

    del all_ground_truth_location
    del all_predicted_topK
    del total_pred_time
    del total_true_time
    del event_time
    del time_gap
    del event_type
    del flow_in
    del flow_out
    gc.collect()

    return t_loss, hit_ratio, rmse


def train(model, x_tau_mean, x_tau_std, training_data, validation_data, optimizer, scheduler, pred_loss_func, opt):

    pt_matrix_file_name = './data_so/Probabilistic_Transfer_Matrix.npz'
    data = np.load(pt_matrix_file_name, allow_pickle=True)
    pt_matrix = data['X']
    pt_matrix = torch.torch.FloatTensor(pt_matrix).to(opt.device)

    """ Start training. """

    valid_event_losses = []  # validation log-likelihood
    valid_pred_hit1 = []  # validation event type prediction accuracy
    valid_pred_hit5 = []
    valid_pred_hit10 = []
    valid_pred_hit20 = []
    valid_rmse = []  # validation event time prediction RMSE
    for epoch_i in range(opt.epoch):
        epoch = epoch_i + 1
        print('[ Epoch', epoch, ']')

        torch.cuda.empty_cache()
        start = time.time()
        train_event, hit_ratio_train, train_time = train_epoch(model, x_tau_mean, x_tau_std, training_data, optimizer,
                                                               pred_loss_func, opt,pt_matrix)
        torch.cuda.empty_cache()

        print('  - (Training)    loglikelihood: {ll: 8.5f}, '
              'hit@1: {h1: 8.5f}, '
              'hit@5: {h5: 8.5f}, '
              'hit@10: {h10: 8.5f}, '
              'hit@20: {h20: 8.5f}, '
              'RMSE: {rmse: 8.5f}, '
              'elapse: {elapse:3.3f} min'
              .format(ll=train_event, h1=hit_ratio_train[0], h5=hit_ratio_train[4], h10=hit_ratio_train[9],
                      h20=hit_ratio_train[19], rmse=train_time, elapse=(time.time() - start) / 60))

        start = time.time()
        valid_event, hit_ratio_valid, valid_time = eval_epoch(model, x_tau_mean, x_tau_std, validation_data,
                                                              pred_loss_func, opt,pt_matrix)
        torch.cuda.empty_cache()
        print('  - (Testing)     loglikelihood: {ll: 8.5f}, '
              'hit@1: {h1: 8.5f}, '
              'hit@5: {h5: 8.5f}, '
              'hit@10: {h10: 8.5f}, '
              'hit@20: {h20: 8.5f}, '
              'RMSE: {rmse: 8.5f}, '
              'elapse: {elapse:3.3f} min'
              .format(ll=valid_event, h1=hit_ratio_valid[0], h5=hit_ratio_valid[4], h10=hit_ratio_valid[9],
                      h20=hit_ratio_valid[19], rmse=valid_time, elapse=(time.time() - start) / 60))

        valid_event_losses += [valid_event]
        valid_pred_hit1 += [hit_ratio_valid[0]]
        valid_pred_hit5 += [hit_ratio_valid[4]]
        valid_pred_hit10 += [hit_ratio_valid[9]]
        valid_pred_hit20 += [hit_ratio_valid[19]]

        valid_rmse += [valid_time]
        print('  - [Info] Maximum ll: {event: 8.5f}, '
              'Maximum h1: {predh1: 8.5f}, '
              'Maximum h5: {predh5: 8.5f}, '
              'Maximum h10: {predh10: 8.5f}, '
              'Maximum h20: {predh20: 8.5f}, '
              'Minimum RMSE: {rmse: 8.5f}'
              .format(event=max(valid_event_losses), predh1=max(valid_pred_hit1), predh5=max(valid_pred_hit5),
                      predh10=max(valid_pred_hit10), predh20=max(valid_pred_hit20), rmse=min(valid_rmse)))

        # logging
        with open(opt.log, 'a') as f:
            f.write('{epoch}, {ll: 8.5f}, {acc: 8.5f}, {rmse: 8.5f}\n'
                    .format(epoch=epoch, ll=valid_event, acc=hit_ratio_valid[0], rmse=valid_time))

        scheduler.step()


def main():
    """ Main function. """

    parser = argparse.ArgumentParser()

    parser.add_argument('-data', default='./data_so/length128_withadjmx_feature31.npz', type=str)

    parser.add_argument('-epoch', type=int, default=100)
    parser.add_argument('-batch_size', type=int, default=2)

    parser.add_argument('-d_model', type=int, default=512)
    parser.add_argument('-d_rnn', type=int, default=64)
    parser.add_argument('-d_inner_hid', type=int, default=1024)
    parser.add_argument('-d_k', type=int, default=512)
    parser.add_argument('-d_v', type=int, default=512)

    parser.add_argument('-n_head', type=int, default=4)
    parser.add_argument('-n_layers', type=int, default=4)

    parser.add_argument('-dropout', type=float, default=0.1)
    parser.add_argument('-lr', type=float, default=1e-4)
    parser.add_argument('-smooth', type=float, default=0.1)

    parser.add_argument('-log', type=str, default='log.txt')

    opt = parser.parse_args()
    import os
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'

    # default device is CUDA
    opt.device = torch.device('cuda')

    # setup the log file
    with open(opt.log, 'w') as f:
        f.write('Epoch, Log-likelihood, Accuracy, RMSE\n')

    print('[Info] parameters: {}'.format(opt))

    """ prepare dataloader """
    trainloader, testloader, num_types, x_tau_mean, x_tau_std, trainY_tau_mean, trainY_tau_std = prepare_dataloader(opt)

    """ prepare model """
    prediction_t = 1
    prediction_s = 1
    hidden_size = 64
    rnn_type = 'LSTM'
    venue_cnt = 62
    mark_embedding_size = 64
    time_interval_minutes = 10
    time_embedding_size = 64
    dropout = 0.0
    num_of_rnn_layers = 2
    n_components = 4

    general_config = MSTPP_ModelConfig(loc_num=int(venue_cnt), loc_emb_size=mark_embedding_size,
                                        time_interval_minutes=time_interval_minutes, tim_emb_size=time_embedding_size,
                                        hidden_size=hidden_size, rnn_type=rnn_type, num_layers=num_of_rnn_layers,
                                        dropout=dropout, n_components=n_components, shift_init=trainY_tau_mean,
                                        scale_init=trainY_tau_std)

    # Define model
    model = MSTPP(general_config).cuda()
    # Define model
    ## 初始化参数
    for p in model.parameters():
        if p.dim() > 1:
            nn.init.xavier_uniform_(p)
    model.to(opt.device)

    """ optimizer and scheduler """
    optimizer = optim.Adam(filter(lambda x: x.requires_grad, model.parameters()),
                           opt.lr, betas=(0.9, 0.999), eps=1e-08)
    scheduler = optim.lr_scheduler.StepLR(optimizer, 1000, gamma=0.5)

    """ prediction loss function, either cross entropy or label smoothing """
    if opt.smooth > 0:
        pred_loss_func = Utils.LabelSmoothingLoss(opt.smooth, num_types, ignore_index=-1)
    else:
        pred_loss_func = nn.CrossEntropyLoss(ignore_index=-1, reduction='none')

    """ number of parameters """
    num_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print('[Info] Number of parameters: {}'.format(num_params))

    """ train the model """
    train(model, x_tau_mean, x_tau_std, trainloader, testloader, optimizer, scheduler, pred_loss_func, opt)


if __name__ == '__main__':
    main()
